package com.othello.util;

public class OthelloConstants {

    public final static int WIDTH = 8;
    public final static int HEIGHT = 8;

    public enum Turn {
	BLACK, WHITE;
    }

    public enum CellStatus {
	BLACK, WHITE, EMPTY, OFFBOARD
    }
}
